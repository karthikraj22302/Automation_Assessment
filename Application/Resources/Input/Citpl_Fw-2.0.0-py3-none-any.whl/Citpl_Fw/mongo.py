from datetime import datetime
import pandas as pd
from pymongo import MongoClient


class ClsDataBase:
    # mongo_connection_string= "mongodb://localhost:27017/"
    # db_name="alchemy"
    mongo_connection_string = "mongodb://alchemy_d:X0H48fFqG4@98.70.38.191:27017/alchemy_d"
    db_name = "alchemy_d"
    def __init__(self):
        # self.driver = driver  # OUTPUT_PATH= self.get_base_dir_path()
        pass
    def get_mongo_client(self, mongo_connection_string):
        # client = MongoClient("mongodb://localhost:27017/")  # Replace with your MongoDB URI
        client = MongoClient(mongo_connection_string)  # Replace with your MongoDB URI
        return client

    def get_mongo_collection(self, mongo_connection_string, db_name, collection_name):
        client = self.get_mongo_client(mongo_connection_string)
        # db = client['alchemy']  # Replace with your database name
        # collection = db['func_auto_results']  # Replace with your collection name
        db = client[db_name]  # Replace with your database name
        collection = db[collection_name]  # Replace with your collection name
        return collection

    def log_test_result(self, request):
        result = {
            "test_name": "testing db",
            "outcome": "pass",
            "duration": "5ms",
            "timestamp": datetime.now()}
        # Insert the result into MongoDB
        collection = self.get_mongo_collection(self.mongo_connection_string, self.db_name, "func_auto_results")
        collection.insert_one(result)

    def upload_excel_into_mongo_db(self, excel_file_path_with_extn, sheet_name):
        # Step 1: Read the Excel file into a pandas DataFrame, treating the first row as headers
        df = pd.read_excel(excel_file_path_with_extn, sheet_name=sheet_name, header=0)

        df = df.where(pd.notnull(df), None)

        # Print the DataFrame to verify the content
        print(f"DataFrame is :: \n{df}")

        # Step 2: Convert DataFrame to dictionary format suitable for MongoDB
        data = df.to_dict(orient='records')


        # Step 3: Insert the data into the MongoDB collection
        collection = self.get_mongo_collection(self.mongo_connection_string, self.db_name, "perf_auto_results")
        collection.insert_many(data)

        print(f"Data from sheet '{sheet_name}' uploaded successfully to MongoDB!")


# di= ClsDataBase()
# di.upload_excel_into_mongo_db("/Users/citpl/Downloads/Trove Performance Testing.xlsx", "perf_test_results")