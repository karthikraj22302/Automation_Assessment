import inspect
import os
import pprint as pp
import random
# import seaborn as sns
import time
from datetime import datetime

import pandas as pd
# from matplotlib import pyplot as plt
from pandas import read_csv, read_excel, read_json, read_html
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.ui import WebDriverWait


class ClsSeleniumBase():
    wait_time_out = 20
    REPLACE_STRING_XXXXXX = "xxxxxx"

    # OUTPUT_PATH="../Output/"
    # OUTPUT_PATH="/Users/citpl/Documents/Py_Workspace/budgie_2_4/Application/Resources/Output/"

    def __init__(self, driver):
        self.driver = driver  # OUTPUT_PATH= self.get_base_dir_path()

    def get_web_element(self, locator_type, locator_value):
        we: WebElement is None
        if locator_type == "xpath":
            # WebDriverWait(self.driver, self.wait_time_out).until(
            #     expected_conditions.presence_of_element_located((By.XPATH, locator_value)))
            WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.XPATH, locator_value)))
            we = self.driver.find_element(By.XPATH, locator_value)

        elif locator_type == "id":
            WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.ID, locator_value)))
            we = self.driver.find_element(By.ID, locator_value)
        elif locator_type == "name":
            WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.NAME, locator_value)))
            we = self.driver.find_element(By.NAME, locator_value)
        elif locator_type == "tag_name":
            WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.TAG_NAME, locator_value)))
            we = self.driver.find_element(By.TAG_NAME, locator_value)
        elif locator_type == "class":
            WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.CLASS_NAME, locator_value)))
            we = self.driver.find_element(By.CLASS_NAME, locator_value)
        elif locator_type == "css":
            WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.CSS_SELECTOR, locator_value)))
            we = self.driver.find_element(By.CSS_SELECTOR, locator_value)
        elif locator_type == "link_text":
            WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.LINK_TEXT, locator_value)))
            we = self.driver.find_element(By.LINK_TEXT, locator_value)
        elif locator_type == "partial_link_text":
            WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.PARTIAL_LINK_TEXT, locator_value)))
            we = self.driver.find_element(By.PARTIAL_LINK_TEXT, locator_value)
        else:
            print("wrong locator type or value")
        return we

    def scroll_into_view(self, locator_type, locator_value):
        # try:
        WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.XPATH, locator_value)))
        self.driver.execute_script("arguments[0].scrollIntoView(true);", self.get_web_element(locator_type, locator_value))

    # except Exception as e:
    #     self.print_in_console(self, "Exception :: " + str(e))

    def click(self, locator_type, locator_value):
        # try:
        WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.element_to_be_clickable((locator_type, locator_value)))
        self.scroll_into_view(locator_type, locator_value)
        self.get_web_element(locator_type, locator_value).click()

    # except Exception as e:
    #     self.print_in_console(self, "Exception :: " + str(e))

    def enter_text(self, locator_type, locator_value, enter_text):
        # try:
        # WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.element_to_be_clickable((locator_type, locator_value)))
        self.scroll_into_view(locator_type, locator_value)
        self.get_web_element(locator_type, locator_value).send_keys(enter_text)

    # except Exception as e:
    #     self.print_in_console(self, "Exception :: " + str(e))  # self.enter_text_by_jse(locator_type, locator_value, enter_text)

    def replace_string(self, source_string, pattern_to_replace, string_to_replace, ):
        return source_string.replace(pattern_to_replace, string_to_replace)

    def click_by_jse(self, locator_type, locator_value):
        # try:
        element = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.element_to_be_clickable((locator_type, locator_value)))
        # self.scroll_into_view(locator_type, locator_value)
        self.driver.execute_script("arguments[0].click();", element)

    def click_by_jse_after_scroll_into_view(self, locator_type, locator_value):
        # try:
        element = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.element_to_be_clickable((locator_type, locator_value)))
        self.scroll_into_view(locator_type, locator_value)
        self.driver.execute_script("arguments[0].click();", element)

    def enter_text_by_jse(self, locator_type, locator_value, text):
        self.scroll_into_view(locator_type, locator_value)
        script = "arguments[0].value = arguments[1];"
        self.driver.execute_script(script, self.get_web_element(locator_type, locator_value), text)

    def click_by_actions(self, locator_type, locator_value):
        element = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.element_to_be_clickable((locator_type, locator_value)))
        actions = ActionChains(self.driver)
        actions.click(self.get_web_element(locator_type, locator_value)).perform()  # actions.scroll_by_amount(5,5)

    def click_by_actions_after_move_to_element(self, locator_type, locator_value):
        element = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.element_to_be_clickable((locator_type, locator_value)))
        self.scroll_into_view(locator_type, locator_value)
        actions = ActionChains(self.driver)
        actions.move_to_element(self.get_web_element(locator_type, locator_value)).perform()
        actions.click(self.get_web_element(locator_type, locator_value)).perform()  # actions.scroll_by_amount(5,5)

    def hover_over_by_actions(self, locator_type, locator_value):
        element = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.element_to_be_clickable((locator_type, locator_value)))
        self.scroll_into_view(locator_type, locator_value)
        actions = ActionChains(self.driver)
        actions.move_to_element(self.get_web_element(locator_type, locator_value)).perform()

    def scroll_by_amount(self, locator_type, locator_value, x, y):
        # try:
        # self.scroll_into_view(locator_type, locator_value)
        actions = ActionChains(self.driver)
        # self.fire_event(locator_type,locator_value,"click")
        # actions.send_keys(Keys.ARROW_DOWN)
        # actions.send_keys(Keys.PAGE_DOWN)
        # actions.move_to_element(self.get_web_element(locator_type, locator_value))
        # actions.scroll_to_element(self.get_web_element(locator_type, locator_value))
        # actions.click(self.get_web_element(locator_type, locator_value)).perform()
        # actions.scroll_by_amount(5,5)
        actions.click_and_hold(self.get_web_element(locator_type, locator_value)).perform()
        actions.move_by_offset(x, y).release().perform()
        ClsSeleniumBase.sleep(self, 15)

    # except Exception as e:
    #     self.print_in_console(self, "Exception :: " + str(e))

    def enter_text_by_actions(self, locator_type, locator_value, text):
        # try:
        actions = ActionChains(self.driver)
        actions.click(self.get_web_element(locator_type, locator_value)).send_keys(text).perform()

    # except Exception as e:
    #     self.print_in_console(self, "Exception :: " + str(e))

    def assert_condition(self, condition, success_message, failure_message):
        assert condition, ("FAILED :: AS UNEXPECTED :: " + failure_message)
        print("PASSED :: AS EXPECTED :: " + success_message)

    def is_element_visible(self, locator_type, locator_value):
        visibility = False
        self.scroll_into_view(locator_type, locator_value)
        if locator_type == "xpath":
            visibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.XPATH, locator_value)))
        elif locator_type == "id":
            visibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.ID, locator_value)))
        elif locator_type == "name":
            visibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.NAME, locator_value)))
        elif locator_type == "tag_name":
            visibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.TAG_NAME, locator_value)))
        elif locator_type == "class":
            visibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.CLASS_NAME, locator_value)))
        elif locator_type == "css":
            visibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.CSS_SELECTOR, locator_value)))
        elif locator_type == "link_text":
            visibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.LINK_TEXT, locator_value)))
        elif locator_type == "partial_link_text":
            visibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.visibility_of_element_located((By.PARTIAL_LINK_TEXT, locator_value)))
        else:
            self.print_in_console(self, "Is element visible? :: " + str(visibility))
        return visibility

    def is_element_not_visible(self, locator_type, locator_value):
        invisibility = False
        self.scroll_into_view(locator_type, locator_value)
        if locator_type == "xpath":
            invisibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.invisibility_of_element((By.XPATH, locator_value)))
        elif locator_type == "id":
            invisibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.invisibility_of_element((By.ID, locator_value)))
        elif locator_type == "name":
            invisibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.invisibility_of_element((By.NAME, locator_value)))
        elif locator_type == "tag_name":
            invisibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.invisibility_of_element((By.TAG_NAME, locator_value)))
        elif locator_type == "class":
            invisibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.invisibility_of_element((By.CLASS_NAME, locator_value)))
        elif locator_type == "css":
            invisibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.invisibility_of_element((By.CSS_SELECTOR, locator_value)))
        elif locator_type == "link_text":
            invisibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.invisibility_of_element((By.LINK_TEXT, locator_value)))
        elif locator_type == "partial_link_text":
            invisibility = WebDriverWait(self.driver, self.wait_time_out).until(expected_conditions.invisibility_of_element((By.PARTIAL_LINK_TEXT, locator_value)))
        else:
            print("wrong locator type or value")
        return invisibility

    # @staticmethod
    def sleep(self, time_in_seconds):
        self.print_in_console(self, "User message :: Hard sleep :: " + str(time_in_seconds))
        time.sleep(time_in_seconds)

    @staticmethod
    def print_in_console(self, object_or_text_to_print):
        pp.pprint("User message :: " + object_or_text_to_print)

    def get_locator_value_replaced(self, locator_type, source_text, text_to_replace):
        s = ""
        if locator_type == "xpath":
            s = self.replace_string(source_text, "xxxxxx", text_to_replace)
            print("User Message :: String after replacement :: " + s)

        elif locator_type == "css":
            pass
        elif locator_type == "id":
            pass
        elif locator_type == "name":
            pass
        else:
            self.print_in_console(self, "Something went wrong!")
        return s

    def press_down_key_until_visible(self, locator_type, locator_value):
        self.print_in_console(self, "press_down_key_until_visible :: ")
        # try:
        element = self.get_web_element(locator_type, locator_value)
        self.print_in_console(self, "Element is displayed :: ")
        # while not element.is_displayed():
        while not self.is_element_visible(locator_type, locator_value):
            self.print_in_console(self, "Element is not displayed :: ")  # element.send_keys(Keys.ARROW_DOWN)
        # self.click(locator_type, locator_value)
        # self.click_by_jse(locator_type, locator_value)
        # self.click_by_actions(locator_type, locator_value)
        self.scroll_by_amount(locator_type, locator_value)  # except Exception as e:  #     print(f"An error occurred while pressing down key: {e}")

    def fire_event(self, locator_type, locator_value, event_name):
        # try:
        element = self.get_web_element(locator_type, locator_value)
        self.driver.execute_script(f"arguments[0].dispatchEvent(new Event('{event_name}'));", element)  # except Exception as e:

    #     print(f"An error occurred while firing event {event_name} on element: {e}")

    def scroll_to_top(self):
        self.driver.execute_script("window.scrollTo(0, 0);")

    def generate_random_number(self, min_digits, max_digits):
        if min_digits < 1 or max_digits < 1 or min_digits > max_digits:
            raise ValueError("min_digits and max_digits must be positive and min_digits must be less than or equal to max_digits.")

        min_value = 10 ** (min_digits - 1)
        max_value = (10 ** max_digits) - 1

        return random.randint(min_value, max_value)

    def get_current_method_name(self):
        current_frame = inspect.currentframe()
        caller_frame = current_frame.f_back
        caller_method = caller_frame.f_code.co_name
        print("Current method name is " + caller_method)
        return caller_method

    @staticmethod
    def capitalize_first_letter(self, text):
        if not text:
            return text
        return text[0].upper() + text[1:].lower()

    def send_failure(self):
        self.assert_condition(False, "Test case yet to be developed!", "Test case yet to be developed!")

    # def log_test_status_in_csv(test_case_id, status):
    #     # OUTPUT_PATH = "/Users/citpl/Documents/Py_Workspace/budgie_2_4/Application/Resources/Output/"
    #     OUTPUT_PATH = ClsSeleniumBase.get_parent_dir_path() + "/Application/Resources/Output/"
    #     log_file = OUTPUT_PATH + 'test_case_status.csv'
    #
    #     file_exists = os.path.isfile(log_file)
    #
    #     with open(log_file, mode='a', newline='') as file:
    #         writer = csv.writer(file)
    #         if not file_exists:
    #             # Write header if file doesn't exist
    #             writer.writerow(['TestCaseID', 'Status'])
    #
    #         writer.writerow([test_case_id, status])

    def get_text(self, locator_name, locator_value):
        element = self.get_web_element(locator_name, locator_value)
        text = element.text
        print("Text obtained from element:", text)
        return str(text)

    @staticmethod
    def get_current_date(date_format):
        current_date = datetime.now().strftime(date_format)
        print("Current Date is :", current_date)
        return str(current_date)

    @staticmethod
    def get_current_time(time_format):
        current_time = datetime.now().strftime(time_format)
        print("Current Time is :", current_time)
        return str(current_time)

    @staticmethod
    def round_decimal(number_to_round, decimal_points):
        print("Number to round :: " + str(number_to_round))
        print("Decimal points to round :: " + str(decimal_points))
        return str(round(number_to_round, decimal_points))

    @staticmethod
    def get_data_frame(file_type, file_name_with_path_and_extn):
        df = ""
        if file_type == 'csv':
            df = pd.read_csv(file_name_with_path_and_extn)
            print("Data frame is :: " + str(df))
        elif file_type == 'excel':
            df = pd.read_excel(file_name_with_path_and_extn)
            print("Data frame is :: " + str(df))
        return df

    @staticmethod
    def get_test_result_data_frame(file_type, file_name_with_path_and_extn, additional_env_properties, test_result_template_file_path, test_result_html_file_path):
        test_result_dict = {}
        chart_1_stat_total = []
        test_case_row_singles = ""
        test_case_row_multiples = ""

        df = ClsSeleniumBase.get_data_frame(file_type, file_name_with_path_and_extn)

        test_case_count_total = df.Status.count()
        print("test_case_count_total :: " + str(test_case_count_total))

        test_case_status_count = df['Status'].value_counts()
        print("test_case_status_count :: " + str(test_case_status_count))

        test_result_dict = test_case_status_count.to_dict()
        print("test_result_dict :: " + str(test_result_dict))
        print("test_result_dict passed :: " + str(test_result_dict.get("passed")))

        chart_1_stat_total.append(test_case_count_total)
        chart_1_stat_total.append(str(test_result_dict.get("passed")))
        chart_1_stat_total.append(str(test_result_dict.get("failed")))
        print("chart_1_stat_total :: " + str(chart_1_stat_total))

        # chart_1_stat_total.append(101)
        # chart_1_stat_total.append(45)
        # chart_1_stat_total.append(67)
        # print("chart_1_stat_total :: " + str(chart_1_stat_total))

        html_template = test_result_template_file_path
        report_file = test_result_html_file_path
        html_template_source_code = ClsSeleniumBase.read_html(html_template)
        with open(report_file, 'w') as file:
            html_template_source_code = html_template_source_code.replace("$url", additional_env_properties.get("url"))
            html_template_source_code = html_template_source_code.replace("$customer", additional_env_properties.get("customer"))
            html_template_source_code = html_template_source_code.replace("$env", additional_env_properties.get("env"))
            html_template_source_code = html_template_source_code.replace("$os", ClsSeleniumBase.get_os())
            html_template_source_code = html_template_source_code.replace("$total", str(test_case_count_total))
            html_template_source_code = html_template_source_code.replace("$pass", str(test_result_dict.get("passed")))
            html_template_source_code = html_template_source_code.replace("$fail", str(test_result_dict.get("failed")))
            html_template_source_code = html_template_source_code.replace("$skipped", str(test_result_dict.get("skipped")))
            html_template_source_code = html_template_source_code.replace("$doe", ClsSeleniumBase.get_current_date("%Y-%m-%d"))

            # Create chart js
            html_template_source_code = html_template_source_code.replace("$chart_1_data", str(chart_1_stat_total))


            # Create html content for list of test cases looping through.
            for index, row in df.iterrows():
                print("row['Time'] :: " + row['Time'])

                test_case_row_singles += "<tr>" + "<td>" + str(index) + "</td>" + "<td>" + "test_case_id" + "</td>" + "<td>" + "Functional test" + "</td>" + "<td>" + row['Test_Case_Name'] + "</td>" + "<td>" + row['Status'] + "</td>" + "<td>" + str(row['Duration']) + "</td>" + "<td><a href= " + str(
                    row['Screenshot']) + ">View</a></td>" + "</tr>"
                test_case_row_multiples += test_case_row_multiples
                print("test_case_row_singles :: " + test_case_row_singles)
                print("test_case_row_multiples :: " + test_case_row_multiples)

            # Write all the content into HTML file
            html_template_source_code = html_template_source_code.replace("$test_case_row", test_case_row_singles)
            html_content = html_template_source_code
            file.write(html_content)

            print(f"HTML report generated and saved to {report_file}")

    @staticmethod
    def read_file(file_type, file_path_with_name_and_extn):
        if file_type == 'csv':
            return read_csv(file_path_with_name_and_extn)
        elif file_type == 'excel':
            return read_excel(file_path_with_name_and_extn)
        elif file_type == 'json':
            return read_json(file_path_with_name_and_extn)
        elif file_type == 'html':
            return read_html(file_path_with_name_and_extn)
        else:
            raise ValueError("Unsupported file type")

    @staticmethod
    def read_html(file_path_with_name_and_extn):
        # Open the HTML file in read mode
        with open(file_path_with_name_and_extn, "r") as file:
            # Read the content of the file
            html_content = file.read()

        # Print the HTML content as a string
        print(html_content)
        return html_content

    @staticmethod
    def get_os():
        return os.name

    @staticmethod
    def create_folder_if_not_exists(folder_path):
        # Check if the folder exists
        if not os.path.exists(folder_path):
            # Create the folder if it does not exist
            os.makedirs(folder_path)
            print(f"Folder '{folder_path}' created.")
        else:
            print(f"Folder '{folder_path}' already exists.")

    @staticmethod
    def split_string(string_to_split, char_to_split_at, first_or_second_value_to_retrieve):
        # The string to be split
        # string_to_split = "Application/Tests/Settings/Test_002_Settings.py::test_001_02_daily_sign_in"

        # Split the string at '::'
        parts = string_to_split.split(char_to_split_at)
        test_name = ""
        # Get the value after '::'
        if len(parts) > 1:
            if first_or_second_value_to_retrieve == 0:
                test_name = parts[0]
            elif first_or_second_value_to_retrieve == 1:
                test_name = parts[1]
        else:
            test_name = None  # Handle the case where '::' is not found

        print(test_name)
        return str(test_name)

    @staticmethod
    def get_project_parent_dir():
        current_module_path = os.path.abspath(__file__)
        parent_directory_path = os.path.dirname(current_module_path)
        print("Parent directory path:", parent_directory_path)
        return str(parent_directory_path)

    def clear_text(self, locator_type, locator_value):
        try:
            element = self.get_web_element(locator_type, locator_value)
            element.clear()  # Clear the existing text in the input field
        except Exception as e:
            # Handle exceptions or add logging if necessary
            print(f"An error occurred while clearing text: {e}")

    def clear_text_with_backspace(self, locator_type, locator_value):
        try:
            element = self.get_web_element(locator_type, locator_value)
            element.click()  # Ensure the element is focused
            element.send_keys(Keys.CONTROL + "a")  # Select all text in the input field
            element.send_keys(Keys.BACKSPACE)  # Delete the selected text
        except Exception as e:
            print(f"An error occurred while clearing text: {e}")

    def clear_text_with_js(self, locator_type, locator_value):
        try:
            element = self.get_web_element(locator_type, locator_value)
            self.driver.execute_script("arguments[0].value = '';", element)
        except Exception as e:
            print(f"An error occurred while clearing text with JavaScript: {e}")

    def scroll_to_element_horizontal(self, visible_text):
        elements = self.driver.find_elements(By.XPATH, f"//*[contains(text(), '{visible_text}')]")
        if elements:
            element = elements[0]
            actions = ActionChains(self.driver)
            actions.move_to_element(element).perform()
            print(f"'{visible_text}' Successfully scrolled to the element with text is found")
        else:
            print(f"'{visible_text}' Failed to scrolled to the element with text is not found")
            return False
        return True

    def scroll_to_element_vertical(self, visible_text):
        elements = self.driver.find_elements(By.XPATH, f"//*[contains(text(), '{visible_text}')]")
        if elements:
            element = elements[0]
            self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
            print(f"'{visible_text}' Successfully scrolled to the element with text found")
        else:
            print(f"'{visible_text}' Failed to scroll to the element with text not found")
            return False
        return True

    def refresh_page(self):
        self.driver.refresh()

    def scroll_down(driver, pixels):
        driver.execute_script(f"window.scrollBy(0, {pixels});")

    def scroll_to_bottom(driver):
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

    def execute_script(self, param):
        pass
