import os

import openpyxl

from Citpl_Fw.SeleniumBase import ClsSeleniumBase as sb


# def get_input_test_data(test_case_id):
#     global data
#
#     excel_file_path = sb.get_parent_dir_path() + env.TEST_DATE_FILE
#     print("excel_file_path", excel_file_path)
#
#     wb = openpyxl.load_workbook(excel_file_path)
#     # Select the active worksheet
#     ws = wb.active
#
#     # Get the column names
#     columns = [cell.value for cell in ws[1]]
#     test_data = [row[columns.index('test_data')].value for row in ws.iter_rows(min_row=2, max_col=len(columns)) if row[columns.index('tc_id')].value == test_case_id]
#
#     # Process the test data
#     data_dict = {}
#     for data in test_data:
#         data_items = data.split('|')
#         for item in data_items:
#             if ':' in item:
#                 key, value = item.split(':')
#                 data_dict[key.strip()] = value.strip()
#
#     # Print the result or use it as needed
#     print(data_dict)
#
#     # Optionally, you can reset the index of the DataFrame
#     # df.reset_index(drop=True, inplace=True)
#
#     # Close the workbook
#     wb.close()
#     return data_dict



def get_input_test_data(test_case_id, parent_dir_path):
        # Get the parent directory path
        # sb = SomeClass()
        excel_file_path = parent_dir_path+ "/Input/Test_Data_Excel.xlsx"
        print("excel_file_path:", excel_file_path)

        # Load the Excel workbook and select the active worksheet
        wb = openpyxl.load_workbook(excel_file_path)
        ws = wb.active

        # Get the column names from the first row
        columns = [cell.value for cell in ws[1]]

        # Dictionaries to store test data and other column values
        test_data_dict = {}
        other_data_dict = {}

        # Process the rows to find the matching test case ID
        for row in ws.iter_rows(min_row=2, values_only=True):
            if row[columns.index('tc_id')] == test_case_id:
                # Extract and parse the test_data column
                test_data_value = row[columns.index('test_data')]
                if test_data_value:
                    for item in test_data_value.split('|'):
                        if ':' in item:
                            key, value = item.split(':')
                            test_data_dict[key.strip()] = value.strip()

                # Extract other column values
                for column, value in zip(columns, row):
                    if column != 'test_data' and column != 'tc_id':
                        other_data_dict[column] = value

        # Merge the two dictionaries
        merged_dict = {**test_data_dict, **other_data_dict}
        print("merged_dict"+str(merged_dict))

        # Close the workbook
        wb.close()

        # Return the merged dictionary
        return merged_dict