import logging


class Cls_Logger():

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    # Configure logging
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # Create a logger
    logger = logging.getLogger(__name__)

    # Log messages
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")

    def get_log(user_message):
        # self(driver)logger.info("User Message :: " + user_message)
        pass
