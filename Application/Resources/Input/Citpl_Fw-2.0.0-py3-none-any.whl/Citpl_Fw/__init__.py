
def get_alchemy_init():
    print("Hello Alchemist!")